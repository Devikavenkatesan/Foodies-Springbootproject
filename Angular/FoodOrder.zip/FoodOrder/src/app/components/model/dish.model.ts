export interface Dish{
    dishId:number;
    dishname:string;
    image: string;
    mrpPrice:number;
    category:string;
    description:string;
}